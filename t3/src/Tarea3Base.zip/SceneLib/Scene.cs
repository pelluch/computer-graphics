﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using System.Globalization;
using System.IO;
using System.Drawing;

namespace SceneLib
{
  /// <summary>
  /// Represents a Scene to be rendered
  /// </summary>
  public class Scene
  {

    public CultureInfo CultureInfo { get; set; } //Used to read XML scene file

    private int width, height;
    private SceneBackground background;
    private Dictionary<string, SceneMaterial> materialsTable; //Assocaites names to materials
    private List<SceneObject> objects; //list of objects in scene
    private List<SceneLight> lights; //list of lights
    private List<SceneCamera> cameras; //list of cameras
    private int currentCamera = 0;
    private SceneCamera camera;


    public List<SceneObject> Objects { get { return objects; } }
    public int Width { get { return width; } set { width = value; } }
    public int Height { get { return height; } set { height = value; } }
    public SceneCamera Camera { get { return camera; } set { camera = value; } }  //First camera
    public SceneBackground Background { get { return background; } }
    public List<SceneLight> Lights { get { return lights; } set { lights = value; } }
    public List<SceneCamera> Cameras
    {
      get { return cameras; }
      set { cameras = value; }
    }

    public Matrix Transform { get; set; }

    public RenderingParameters RenderParams { get; set; }

    public Scene(int width, int height)
    {
      this.width = width;
      this.height = height;
      materialsTable = new Dictionary<string, SceneMaterial>();
      objects = new List<SceneObject>();
      lights = new List<SceneLight>();
      cameras = new List<SceneCamera>();
      background = new SceneBackground();
      RenderParams = new RenderingParameters();

      CultureInfo = new CultureInfo("en-US");
    }

    public void NextCamera()
    {
      currentCamera = (currentCamera + 1) % cameras.Count;
      this.camera = cameras[currentCamera];
    }

    //Adds a new object to the scene
    public void AddObject(SceneObject obj)
    {
      objects.Add(obj);
    }

    //Gets a material based on a name
    public SceneMaterial GetMaterial(string name)
    {
      if (materialsTable.ContainsKey(name))
        return materialsTable[name];
      return null;
    }

    //Loads a scene from an XML file
    public void Load(string file)
    {
      XDocument xmlDoc = XDocument.Load(file);
      XElement xmlScene = xmlDoc.Elements("scene").First();

      //Loading background
      XElement xmlBackground = xmlScene.Elements("background").First();
      background.AmbientLight = LoadColor(xmlBackground.Elements("ambientLight").First());
      background.Color = LoadColor(xmlBackground.Elements("color").First());

      //Loading camera
      XElement xmlCamera = xmlScene.Elements("camera").FirstOrDefault();
      if (xmlCamera != null)
      {
        SceneCamera cameraNode = new SceneCamera();
        cameraNode.FieldOfView = LoadFloat(xmlCamera, "fieldOfView");
        cameraNode.NearClip = LoadFloat(xmlCamera, "nearClip");
        cameraNode.FarClip = LoadFloat(xmlCamera, "farClip");
        cameraNode.Position = LoadXYZ(xmlCamera.Elements("position").First());
        cameraNode.Target = LoadXYZ(xmlCamera.Elements("target").First());
        cameraNode.Up = LoadXYZ(xmlCamera.Elements("up").First());
        cameras.Add(cameraNode);
      }

      XElement xmlCameras = xmlScene.Elements("camera_list").FirstOrDefault();
      if (xmlCameras != null)
      {
        foreach (XElement cameraNode in xmlCameras.Elements("camera"))
        {
          SceneCamera camera = new SceneCamera();
          camera.FieldOfView = LoadFloat(cameraNode, "fieldOfView");
          camera.NearClip = LoadFloat(cameraNode, "nearClip");
          camera.FarClip = LoadFloat(cameraNode, "farClip");
          camera.Position = LoadXYZ(cameraNode.Elements("position").First());
          camera.Target = LoadXYZ(cameraNode.Elements("target").First());
          camera.Up = LoadXYZ(cameraNode.Elements("up").First());
          cameras.Add(camera);
        }
      }

      XElement xmlLights = xmlScene.Elements("light_list").First();
      foreach (XElement lightNode in xmlLights.Elements("light"))
      {
        SceneLight lightObj = new SceneLight();
        lightObj.Position = LoadXYZ(lightNode.Elements("position").First());
        if (lightNode.Attributes("fieldOfLight").Any())
          lightObj.FieldOfLight = LoadFloat(lightNode, "fieldOfLight");
        if (lightNode.Attributes("type").Any())
          lightObj.TypeOfLight = (LightType)int.Parse(lightNode.Attribute("type").Value);
        else
          lightObj.TypeOfLight = LightType.Point;
        if (lightNode.Elements("target").Any())
        {
          lightObj.PhotonTarget = LoadXYZ(lightNode.Elements("target").First());
          lightObj.Direction = (lightObj.Position - lightObj.PhotonTarget).Normalize3();
        }
        if (lightNode.Elements("target").Any())
          lightObj.PhotonUp = LoadXYZ(lightNode.Elements("up").First());
        if (lightObj.PhotonTarget == null || lightObj.PhotonUp == null)
          lightObj.CanCreatePhotonMap = false;
        else
          lightObj.CanCreatePhotonMap = true;
        if (lightNode.Elements("a").Any())
          lightObj.A = LoadXYZ(lightNode.Elements("a").First());
        if (lightNode.Elements("b").Any())
          lightObj.B = LoadXYZ(lightNode.Elements("b").First());
        lightObj.Color = LoadColor(lightNode.Elements("color").First());
        XElement atenuationNode = lightNode.Elements("attenuation").First();
        lightObj.AtenuationConstant = LoadFloat(atenuationNode, "constant");
        lightObj.AtenuationLinear = LoadFloat(atenuationNode, "linear");
        lightObj.AtenuationQuadratic = LoadFloat(atenuationNode, "quadratic");

        lights.Add(lightObj);
      }

      XElement xmlMaterials = xmlScene.Elements("material_list").First();
      foreach (XElement materialNode in xmlMaterials.Elements("material"))
      {
        string name = materialNode.Attribute("name").Value;
        SceneMaterial material = new SceneMaterial();
        if (materialNode.Elements("texture").Any())
          material.TextureFile = materialNode.Elements("texture").First().Attribute("filename").Value;
        if (material.TextureFile != null && material.TextureFile != String.Empty && File.Exists(material.TextureFile))
          material.TextureImage = (Bitmap)Bitmap.FromFile(material.TextureFile);
        if (materialNode.Elements("bumpmap").Any())
          material.BumpFile = materialNode.Elements("bumpmap").First().Attribute("filename").Value;
        if (material.BumpFile != null && material.BumpFile != String.Empty && File.Exists(material.BumpFile))
          material.BumpImage = (Bitmap)Bitmap.FromFile(material.BumpFile);
        if (materialNode.Elements("normalmap").Any())
          material.NormalFile = materialNode.Elements("normalmap").First().Attribute("filename").Value;
        if (material.NormalFile != null && material.NormalFile != String.Empty && File.Exists(material.NormalFile))
          material.NormalImage = (Bitmap)Bitmap.FromFile(material.NormalFile);
        if (materialNode.Elements("environmentmap").Any())
          material.EnvironmentMapFile = materialNode.Elements("environmentmap").First().Attribute("filename").Value;
        if (materialNode.Elements("specular").Any())
          material.Specular = LoadSpecular(materialNode.Elements("specular").First());
        if (materialNode.Elements("diffuse").Any())
          material.Diffuse = LoadColor(materialNode.Elements("diffuse").First());
        if (materialNode.Elements("transparent").Any())
          material.Transparent = LoadColor(materialNode.Elements("transparent").First());
        if (materialNode.Elements("reflective").Any())
          material.Reflective = LoadColor(materialNode.Elements("reflective").First());
        if (materialNode.Elements("refraction_index").Any())
          material.RefractionIndex = LoadColor(materialNode.Elements("refraction_index").First());
        materialsTable.Add(name, material);
      }

      XElement xmlObjects = xmlScene.Elements("object_list").First();

      foreach (XElement modelNode in xmlObjects.Elements("model"))
      {
        SceneModel model = new SceneModel(modelNode.Attribute("name").Value, modelNode.Attribute("path").Value);
        XDocument xmlModel = XDocument.Load(model.FileName);
        XElement xmlSceneModel = xmlModel.Elements("model").First();

        model.Scale = LoadXYZ(modelNode.Elements("scale").First());
        model.Position = LoadXYZ(modelNode.Elements("position").First());
        model.Rotation = LoadXYZ(modelNode.Elements("rotation").First());

        XElement xmlTriangles = xmlSceneModel.Elements("triangle_list").First();

        foreach (XElement triangleNode in xmlTriangles.Elements("triangle"))
        {
          SceneTriangle triangle = new SceneTriangle();
          triangle.Scale = LoadXYZ(triangleNode.Elements("scale").First());
          triangle.Position = LoadXYZ(triangleNode.Elements("position").First());
          triangle.Rotation = LoadXYZ(triangleNode.Elements("rotation").First());

          foreach (XElement vertexNode in triangleNode.Elements("vertex"))
          {
            triangle.Materials.Add(materialsTable[vertexNode.Attribute("material").Value]);
            triangle.Vertices.Add(LoadXYZ(vertexNode.Elements("position").First()));
            triangle.Normal.Add(LoadXYZ(vertexNode.Elements("normal").First()));
            XElement textNode = vertexNode.Elements("texture").First();
            triangle.U.Add(LoadFloat(textNode, "u"));
            triangle.V.Add(LoadFloat(textNode, "v"));
          }
          model.Triangles.Add(triangle);
        }

        objects.Add(model);
      }

      foreach (XElement triangleNode in xmlObjects.Elements("triangle"))
      {
        SceneTriangle triangle = new SceneTriangle();
        triangle.Scale = LoadXYZ(triangleNode.Elements("scale").First());
        triangle.Position = LoadXYZ(triangleNode.Elements("position").First());
        triangle.Rotation = LoadXYZ(triangleNode.Elements("rotation").First());

        foreach (XElement vertexNode in triangleNode.Elements("vertex"))
        {
          triangle.Materials.Add(materialsTable[vertexNode.Attribute("material").Value]);
          triangle.Vertices.Add(LoadXYZ(vertexNode.Elements("position").First()));
          triangle.Normal.Add(LoadXYZ(vertexNode.Elements("normal").First()));
          XElement textNode = vertexNode.Elements("texture").First();
          triangle.U.Add(LoadFloat(textNode, "u"));
          triangle.V.Add(LoadFloat(textNode, "v"));
        }
        objects.Add(triangle);
      }

      foreach (XElement sphereNode in xmlObjects.Elements("sphere"))
      {
        SceneSphere sphere = new SceneSphere();
        sphere.Radius = LoadFloat(sphereNode, "radius");
        sphere.Material = materialsTable[sphereNode.Attribute("material").Value];
        sphere.Scale = LoadXYZ(sphereNode.Elements("scale").First());
        sphere.Position = LoadXYZ(sphereNode.Elements("position").First());
        sphere.Rotation = LoadXYZ(sphereNode.Elements("rotation").First());
        sphere.Center = LoadXYZ(sphereNode.Elements("center").First());
        sphere.Velocity = LoadXYZ(sphereNode.Elements("velocity").FirstOrDefault());
        objects.Add(sphere);
      }

      if (cameras.Count > 0)
        this.camera = cameras[0];
    }

    #region LoadHelpers
    private float LoadFloat(XElement node, string attribute)
    {
      if (node == null)
        return 0;
      float value = 0;
      float.TryParse(node.Attribute(attribute).Value, NumberStyles.Number, CultureInfo, out value);
      return value;
    }

    private Vector LoadXYZ(XElement node)
    {
      if (node == null)
        return new Vector();
      return new Vector(LoadFloat(node, "x"), LoadFloat(node, "y"), LoadFloat(node, "z"));
    }

    private Vector LoadColor(XElement node)
    {
      return new Vector(LoadFloat(node, "red"), LoadFloat(node, "green"), LoadFloat(node, "blue"));
    }

    private Vector LoadSpecular(XElement node)
    {
      return new Vector(LoadFloat(node, "red"), LoadFloat(node, "green"), LoadFloat(node, "blue"), LoadFloat(node, "shininess"));
    }
    #endregion
  }
}
